import javax.swing.*;          
import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.event.*;

//Practical 3

//noise reduction 
//edge extraction


public class VisionSystem
{
	public static void main(String[] args)
	{
		new VisionSystem();
	}
		
	//constructor for VisionSystem class
	public VisionSystem()
	{
		try
		{
			//create JVision window
			JVision jvis = new JVision();
			
			//objects to hold image data
			BufferedImage imageOne, imageTwo;
			
			//load image data 
			imageOne = readInImage("images/vehicle3.jpg");
			imageTwo = readInImage("images/vehicle3.jpg");
			
			//reduce noise in image
			imageTwo = performNoiseReduction(imageTwo);
			
			//extract edges in image
			imageTwo = performEdgeExtraction(imageTwo);
			
			//display images in JVision window
			displayAnImage(imageOne, jvis, 1, 1, "Original Image");
			displayAnImage(imageTwo, jvis, 301, 1, "Image with noise reduction");
			
			
		}
		catch(Exception e)
		{
			System.out.println("Error message");
			e.printStackTrace();
		}
    }    
	
	//reads in image data and stores it in BufferedImage object
	public BufferedImage readInImage(String filename)
	{
	    return ImageOp.readInImage(filename);
	}

	//displays image in JVision window provided with a position and title
	public void displayAnImage(BufferedImage img, JVision display, int x, int y, String title)
	{
	    display.imdisp(img,title,x,y);
	}

	//takes image data and uses it to plot a histogram then display on JVision window
	public void createAndDisplayHistogram(BufferedImage img,JVision display,int x,int y,String title) throws Exception
	{
	    Histogram hist = new Histogram(img);
	    GraphPlot gp = new GraphPlot(hist);
	    display.imdisp(gp,title,x,y);
	}
	
	//removes noise from the image
	public BufferedImage performNoiseReduction(BufferedImage source)
	{
		final float[] LOWPASS3X3 = {1/9.f, 1/9.f, 1/9.f,
									1/9.f, 1/9.f, 1/9.f,
									1/9.f, 1/9.f, 1/9.f};
		
		final float[] LOWPASS5X5 = {1/25.f, 1/25.f, 1/25.f, 1/25.f, 1/25.f,
									1/25.f, 1/25.f, 1/25.f, 1/25.f, 1/25.f,
									1/25.f, 1/25.f, 1/25.f, 1/25.f, 1/25.f,
									1/25.f, 1/25.f, 1/25.f, 1/25.f, 1/25.f,
									1/25.f, 1/25.f, 1/25.f, 1/25.f, 1/25.f};
		
		//return ImageOp.convolver(source, LOWPASS5X5);
		return ImageOp.median(source, 5);
	}

	//extracts the edges from an image
	public BufferedImage performEdgeExtraction(BufferedImage source)
	{
		BufferedImage horizontal, vertical;
		
		final float[] HIGHPASS1X2 = {-10.f, 10.f,
									   0.f,  0.f};
		
		final float[] HIGHPASS2X1 = {-10.f, 0.f,
				                      10.f, 0.f};
	
	
		horizontal = ImageOp.convolver(source, HIGHPASS1X2);
		vertical = ImageOp.convolver(source, HIGHPASS2X1);
		
		return ImageOp.imagrad(horizontal, vertical);
	}
}