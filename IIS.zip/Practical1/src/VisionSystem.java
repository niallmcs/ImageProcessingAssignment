import javax.swing.*;          
import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.event.*;

//Practical 1

//create images and display them
//create histograms and display them
 

public class VisionSystem
{
	public static void main(String[] args)
	{
		new VisionSystem();
	}
		
	//constructor for VisionSystem class
	public VisionSystem()
	{
		try
		{
			//create JVision window
			JVision jvis = new JVision();
			
			//objects to hold image data
			BufferedImage imageOne, imageTwo;
			
			//load image data 
			imageOne = readInImage("images/dome256.jpg");
			imageTwo = readInImage("images/boat256.jpg");
			
			//display images in JVision window
			displayAnImage(imageOne, jvis, 1, 1, "Dome Image");
			displayAnImage(imageTwo, jvis, 301, 1, "Boat Image");
			
			//display image histograms
			createAndDisplayHistogram(imageOne, jvis, 1, 301, "Dome Histogram");
			createAndDisplayHistogram(imageTwo, jvis, 301, 301, "Boat Histogram");
		}
		catch(Exception e)
		{
			System.out.println("Error message");
			e.printStackTrace();
		}
    }    
	
	//reads in image data and stores it in BufferedImage object
	public BufferedImage readInImage(String filename)
	{
	    return ImageOp.readInImage(filename);
	}

	//displays image in JVision window provided with a position and title
	public void displayAnImage(BufferedImage img, JVision display, int x, int y, String title)
	{
	    display.imdisp(img,title,x,y);
	}

	//takes image data and uses it to plot a histogram then display on JVision window
	public void createAndDisplayHistogram(BufferedImage img,JVision display,int x,int y,String title) throws Exception
	{
	    Histogram hist = new Histogram(img);
	    GraphPlot gp = new GraphPlot(hist);
	    display.imdisp(gp,title,x,y);
	}
}