import javax.swing.*;          
import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.event.*;

//Practical 4

//preprocess image 
//threshold image
//postprocess image 

public class VisionSystem
{
	public static void main(String[] args)
	{
		new VisionSystem();
	}
		
	//constructor for VisionSystem class
	public VisionSystem()
	{
		try
		{
			JVision jvis = new JVision();
			jvis.setSize(1200, 400);
			
			BufferedImage originalImage, preprocessedImage, thresholdedImage, postprocessedImage;
			
			int area = 0;
			
			//load image data
			originalImage = readInImage("images/vehicle3.jpg");
			
			//preprocess image
			preprocessedImage = preprocessAnImage(originalImage);
			
			//thresholded image
			thresholdedImage = performAutomaticThresholding(preprocessedImage);
			
			//postprocess image
			postprocessedImage = postprocessAnImage(thresholdedImage);
			
			//display image data in JVision
			displayAnImage(originalImage, jvis, 1, 1, "Original Image");
			displayAnImage(preprocessedImage, jvis, 301, 1, "Preprocessed Image");
			displayAnImage(thresholdedImage, jvis, 601, 1, "Thresholded Image");
			displayAnImage(postprocessedImage, jvis, 901, 1, "Postprocessed Image");
			
			area = featureExtractFromAnImage(postprocessedImage);

			System.out.println("Area is " + area);
		}
		catch(Exception e)
		{
			System.out.println("Error message");
			e.printStackTrace();
		}
    }
	
	//reads in image data and stores it in BufferedImage object
	public BufferedImage readInImage(String filename)
	{
	    return ImageOp.readInImage(filename);
	}

	//displays image in JVision window provided with a position and title
	public void displayAnImage(BufferedImage img, JVision display, int x, int y, String title)
	{
	    display.imdisp(img,title,x,y);
	}

	//takes image data and uses it to plot a histogram then display on JVision window
	public void createAndDisplayHistogram(BufferedImage img,JVision display,int x,int y,String title) throws Exception
	{
	    Histogram hist = new Histogram(img);
	    GraphPlot gp = new GraphPlot(hist);
	    display.imdisp(gp,title,x,y);
	}

	public BufferedImage preprocessAnImage(BufferedImage source)
	{
		//reduce noise
		source = performNoiseReduction(source);
		
		//enhance brightness
		source = enhanceBrightness(source);
		
		//enhance contrast
		source = enhanceContrast(source);
		
		return source;
	}
	
	//removes noise from the image
	public BufferedImage performNoiseReduction(BufferedImage source)
	{
		return ImageOp.median(source, 2);
	}
	
	//creates lookup table based on int c
	public short [] brightnessLUT(int c)
	{
		short [] data = new short[256];
		int output = 0;
			
		for(int i = 0; i < data.length; i++)
		{
			if (i <  (c * -1))
			{
				output  = 0;
			}
			else if (i > (255 - c))
			{
				output = 255;
			}
			else
			{
				output =  i + c;
			}
			data[i] = (short) output;
		}
		return data;
	}

	//enhances the brightness of an image
	public BufferedImage enhanceBrightness(BufferedImage source)
	{
		short [] data = brightnessLUT(50);
		source = ImageOp.pixelop(source, data);
		return source;
	}

	//create a linear stretching lookup table
	public short [] linearStretchLUT(double m, double c)
	{
		short [] data = new short[256];
		double output = 0;
			
		for(int i = 0; i < data.length; i++)
		{
			if (i < ((c * -1)/m))
			{
				output = 0;
			}
			else if (i > ((255 - c) / m))
			{
				output = 255;
			}
			else
			{
				output =  m * i + c;
			}
			data[i] = (short) output; 
		}
		return data;
	}
		
	//enhances the contrast of an image
	public BufferedImage enhanceContrast(BufferedImage source)
	{
		short [] data;
			
		try
		{
			//use linear stretching LUT
			data = linearStretchLUT(1.66, -80.0);
			
			source = ImageOp.pixelop(source, data);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return source;
	}

	//calculate a lookup table using the threshold
	public short[] thresholdLUT(double t) 
	{
		short [] data = new short[256];
		int output = 0;
			
		for(int i = 0; i < data.length; i++)
		{
			if (i <= t)
			{
				output = 255;
			}
			else
			{
				output = 0;
			}
			data[i] = (short) output;
		}
		return data;
	}

	//create binary image using threshold LUT
	public BufferedImage thresholdAnImage(BufferedImage source)
	{
		short [] data = thresholdLUT(70);
		source = ImageOp.pixelop(source, data);
		return source;
	}

	//calculate mean of image
	public double mean(BufferedImage source)
	{
		double width = source.getWidth();
		double height = source.getHeight();
		double sum = 0;
		
		Raster raster = source.getRaster();
		
		for(int i = 0; i < width; i++)
		{
			for(int j = 0; j < height; j++)
			{
				sum += raster.getSample(i,j,0);
			}
		}
		return sum / (width * height);
	}

	//calculate standard deviation of image
	public double standardDeviation(BufferedImage source, double mean)
	{
		double width = source.getWidth();
		double height = source.getHeight();
		double sum = 0;
		
		Raster raster = source.getRaster();
		
		for(int i = 0; i < width; i++)
		{
			for(int j = 0; j < height; j++)
			{
				sum += Math.pow((raster.getSample(i,j,0) - mean),2);
			}
		}
		return Math.sqrt(sum / ((width * height) - 1));
	}

	//automatically perform thresholding
	public BufferedImage performAutomaticThresholding(BufferedImage source)
	{
		double average = mean(source);
		double sd = standardDeviation(source, average);
		double a = -0.5;
		double threshold = (average + (a * sd));
		
		short [] data = thresholdLUT(threshold);
		source = ImageOp.pixelop(source, data);
		return source;
	}

	//clean up thresholded image
	public BufferedImage postprocessAnImage(BufferedImage source)
	{
		source = ImageOp.open(source, 3);
		source = ImageOp.close(source, 1);
		
		return source;
	}

	public int featureExtractFromAnImage(BufferedImage source)
	{
		return ImageOp.area(source);
	}
}