import javax.swing.*;          
import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.event.*;

//Practical 2

//use contrast enhancement
//linear stretching
//power law 
//histogram equalization 

public class VisionSystem
{
	public static void main(String[] args)
	{
		new VisionSystem();
	}
		
	//constructor for VisionSystem class
	public VisionSystem()
	{
		try
		{
			//create JVision window
			JVision jvis = new JVision();
			
			//objects to hold image data
			BufferedImage imageOne, imageTwo;
			
			//load image data 
			imageOne = readInImage("images/boat256.jpg");
			imageTwo = readInImage("images/boat256.jpg");
			
			//enhance brightness
			//imageTwo = enhanceBrightness(imageTwo);
			
			//enhance contrast
			imageTwo = enhanceContrast(imageTwo);
			
			//Create graph and display it
			GraphPlot gp;
			//gp = new GraphPlot(brightnessLUT(50));
			//gp = new GraphPlot(linearStretchLUT(1.66, -80));
			//gp = new GraphPlot(powerLawLUT(2));
			gp = new GraphPlot(histogramEqualisationLUT(new Histogram(imageOne)));
			jvis.imdisp(gp,"transfer function",301,1);
			
			//display images in JVision window
			displayAnImage(imageOne, jvis, 1, 1, "Boat Image");
			displayAnImage(imageTwo, jvis, 601, 1, "Enhanced Boat Image");
			
			//display image histograms
			createAndDisplayHistogram(imageOne, jvis, 1, 301, "Boat Histogram");
			createAndDisplayHistogram(imageTwo, jvis, 601, 301, "Enhanced Boat Histogram");
		}
		catch(Exception e)
		{
			System.out.println("Error message");
			e.printStackTrace();
		}
    }    
	
	//reads in image data and stores it in BufferedImage object
	public BufferedImage readInImage(String filename)
	{
	    return ImageOp.readInImage(filename);
	}

	//displays image in JVision window provided with a position and title
	public void displayAnImage(BufferedImage img, JVision display, int x, int y, String title)
	{
	    display.imdisp(img,title,x,y);
	}

	//takes image data and uses it to plot a histogram then display on JVision window
	public void createAndDisplayHistogram(BufferedImage img,JVision display,int x,int y,String title) throws Exception
	{
	    Histogram hist = new Histogram(img);
	    GraphPlot gp = new GraphPlot(hist);
	    display.imdisp(gp,title,x,y);
	}

	//creates lookup table based on int c
	public short [] brightnessLUT(int c)
	{
		short [] data = new short[256];
		int output = 0;
		
		for(int i = 0; i < data.length; i++)
		{
			if (i <  (c * -1))
			{
				output  = 0;
			}
			else if (i > (255 - c))
			{
				output = 255;
			}
			else
			{
				output =  i + c;
			}
			data[i] = (short) output;
		}
		return data;
	}

	//enhances the brightness of an image
	public BufferedImage enhanceBrightness(BufferedImage source)
	{
		short [] data = brightnessLUT(50);
		source = ImageOp.pixelop(source, data);
		return source;
	}
	
	//create a linear stretching lookup table
	public short [] linearStretchLUT(double m, double c)
	{
		short [] data = new short[256];
		double output = 0;
		
		for(int i = 0; i < data.length; i++)
		{
			if (i < ((c * -1)/m))
			{
				output = 0;
			}
			else if (i > ((255 - c) / m))
			{
				output = 255;
			}
			else
			{
				output =  m * i + c;
			}
			data[i] = (short) output; 
		}
		return data;
	
	}

	//create a power law lookup table 
	public short [] powerLawLUT(double gamma)
	{
		short [] data = new short[256];
		
		for(int i = 0; i < data.length; i++)
		{
			data[i] = (short) (Math.pow(i, gamma) / Math.pow(255, gamma - 1));
		}
		return data;
	}
	
	//create a histogram equalisation LUT
	public short[] histogramEqualisationLUT (Histogram hist) throws HistogramException
	{
		short [] data = new short[256];
		
		for(int i = 0; i < data.length; i++)
		{
			data[i] = (short) Math.max(0, (256 * hist.getCumulativeFrequency(i) / hist.getNumSamples()) - 1);
		}
		return data;
	}
	
	//enhances the contrast of an image
	public BufferedImage enhanceContrast(BufferedImage source)
	{
		short [] data;
		
		try
		{
			//use linear stretching LUT
			//data = linearStretchLUT(1.66, -80.0);
		
			//use power law LUT
			//data = powerLawLUT(2);
		
			//use histogram equalisation LUT
			Histogram hist = new Histogram(source);
			data = histogramEqualisationLUT(hist);
					
			source = ImageOp.pixelop(source, data);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return source;
	}
}